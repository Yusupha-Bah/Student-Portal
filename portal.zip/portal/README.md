# UTG Student Portal

A comprehensive full-stack student portal application built with Node.js/Express backend and React frontend, designed to provide students with easy access to their academic information, grades, courses, and more.

## 🚀 Features

### Backend Features
- **Authentication & Authorization**: JWT-based authentication with role-based access control
- **Student Management**: Complete student profile management with academic records
- **Course Management**: Course catalog, registration, and enrollment tracking
- **Grade Management**: Comprehensive grading system with detailed analytics
- **Assignment Tracking**: Assignment submission and grading workflow
- **Financial Management**: Tuition tracking, payment processing, and financial aid
- **Notification System**: Real-time notifications for important updates
- **API Security**: Rate limiting, input validation, and security headers

### Frontend Features
- **Modern UI/UX**: Clean, responsive design with Tailwind CSS
- **Real-time Updates**: Live data updates using React Query
- **Interactive Dashboard**: Comprehensive overview with charts and statistics
- **Mobile Responsive**: Optimized for all device sizes
- **Accessibility**: WCAG compliant design patterns
- **Performance**: Optimized loading and caching strategies

## 🛠️ Tech Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM for MongoDB
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **express-validator** - Input validation
- **helmet** - Security headers
- **cors** - Cross-origin resource sharing

### Frontend
- **React 18** - UI library
- **React Router** - Client-side routing
- **React Query** - Data fetching and caching
- **Tailwind CSS** - Utility-first CSS framework
- **React Hook Form** - Form handling
- **React Hot Toast** - Notifications
- **Heroicons** - Icon library
- **Recharts** - Data visualization

## 📋 Prerequisites

Before running this application, make sure you have the following installed:

- **Node.js** (v16 or higher)
- **npm** or **yarn**
- **MongoDB** (local installation or MongoDB Atlas)

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone <repository-url>
cd utg-student-portal
```

### 2. Install Dependencies

```bash
# Install backend dependencies
npm install

# Install frontend dependencies
cd client
npm install
cd ..
```

### 3. Environment Configuration

Create a `config.env` file in the root directory:

```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/utg_student_portal
JWT_SECRET=your_jwt_secret_key_here_change_in_production
JWT_EXPIRE=30d
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_email_password
CLIENT_URL=http://localhost:3000
```

### 4. Start the Application

#### Development Mode (Both Frontend and Backend)

```bash
# Start both frontend and backend concurrently
npm run dev
```

#### Production Mode

```bash
# Build the frontend
npm run build

# Start the backend
npm start
```

### 5. Access the Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000/api
- **API Health Check**: http://localhost:5000/api/health

## 📚 API Documentation

### Authentication Endpoints

- `POST /api/auth/login` - Student login
- `POST /api/auth/register` - Student registration
- `GET /api/auth/me` - Get current user
- `PUT /api/auth/update-profile` - Update profile
- `PUT /api/auth/change-password` - Change password

### Student Endpoints

- `GET /api/students/profile` - Get student profile
- `GET /api/students/academic-summary` - Get academic summary
- `GET /api/students/schedule` - Get student schedule
- `GET /api/students/notifications` - Get notifications

### Course Endpoints

- `GET /api/courses` - Get all courses
- `GET /api/courses/:id` - Get course by ID
- `GET /api/courses/search` - Search courses
- `GET /api/courses/stats` - Get course statistics

### Grade Endpoints

- `GET /api/grades` - Get student grades
- `GET /api/grades/summary` - Get grade summary
- `GET /api/grades/recent` - Get recent grades

### Registration Endpoints

- `GET /api/registrations` - Get student registrations
- `POST /api/registrations` - Register for course
- `DELETE /api/registrations/:id` - Drop course

### Assignment Endpoints

- `GET /api/assignments` - Get assignments
- `POST /api/assignments/:id/submit` - Submit assignment
- `GET /api/assignments/upcoming` - Get upcoming assignments

### Financial Endpoints

- `GET /api/financial` - Get financial information
- `GET /api/financial/payments` - Get payment history
- `POST /api/financial/pay` - Process payment

## 🗄️ Database Schema

### Student Model
- Personal information (name, email, phone, etc.)
- Academic information (program, level, department, GPA)
- Address and emergency contact
- Profile picture and preferences

### Course Model
- Course details (code, title, description, credits)
- Schedule information (days, times, room)
- Instructor information
- Prerequisites and co-requisites
- Enrollment capacity and status

### Grade Model
- Assignment details and scores
- Letter grades and grade points
- Submission and grading dates
- Comments and feedback

## 🔐 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcrypt for password security
- **Input Validation**: Comprehensive validation using express-validator
- **Rate Limiting**: Protection against brute force attacks
- **CORS Configuration**: Controlled cross-origin requests
- **Security Headers**: Helmet.js for security headers
- **Error Handling**: Centralized error handling middleware

## 🎨 UI Components

The application includes reusable components:

- **Layout**: Main application layout with sidebar and header
- **LoadingSpinner**: Loading states
- **Forms**: Reusable form components with validation
- **Tables**: Data tables with sorting and filtering
- **Cards**: Information cards for dashboard
- **Modals**: Modal dialogs for forms and confirmations

## 📱 Responsive Design

The application is fully responsive and optimized for:

- **Desktop**: Full-featured interface with sidebar navigation
- **Tablet**: Adaptive layout with collapsible sidebar
- **Mobile**: Mobile-first design with touch-friendly interactions

## 🚀 Deployment

### Backend Deployment

1. Set up environment variables for production
2. Configure MongoDB connection
3. Set up reverse proxy (nginx)
4. Use PM2 for process management

### Frontend Deployment

1. Build the application: `npm run build`
2. Serve static files with nginx or CDN
3. Configure API endpoint for production

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:

- Create an issue in the repository
- Contact the development team
- Check the documentation

## 🔄 Updates and Maintenance

- Regular security updates
- Performance optimizations
- Feature enhancements
- Bug fixes and improvements

---

**Note**: This is a demonstration application. For production use, ensure proper security measures, data validation, and error handling are implemented according to your specific requirements. 