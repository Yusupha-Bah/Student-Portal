import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Sidebar from './Sidebar';
import Header from './Header';

const Layout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: 'HomeIcon' },
    { name: 'Grades', href: '/grades', icon: 'AcademicCapIcon' },
    { name: 'Courses', href: '/courses', icon: 'BookOpenIcon' },
    { name: 'Registrations', href: '/registrations', icon: 'ClipboardDocumentListIcon' },
    { name: 'Assignments', href: '/assignments', icon: 'DocumentTextIcon' },
    { name: 'Financial', href: '/financial', icon: 'CurrencyDollarIcon' },
    { name: 'Profile', href: '/profile', icon: 'UserIcon' },
  ];

  return (
    <div className="h-screen flex overflow-hidden bg-gray-100">
      {/* Sidebar */}
      <Sidebar
        navigation={navigation}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        currentPath={location.pathname}
      />

      {/* Main content */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        {/* Header */}
        <Header
          user={user}
          setSidebarOpen={setSidebarOpen}
          currentPath={location.pathname}
        />

        {/* Main content area */}
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout; 