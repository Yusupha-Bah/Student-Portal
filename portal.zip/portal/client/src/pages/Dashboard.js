import React from 'react';
import { useQuery } from 'react-query';
import { 
  AcademicCapIcon, 
  BookOpenIcon, 
  ClockIcon, 
  ExclamationTriangleIcon,
  CheckCircleIcon,
  XCircleIcon
} from '@heroicons/react/24/outline';
import { studentsAPI, notificationsAPI, assignmentsAPI } from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';

const Dashboard = () => {
  const { data: academicSummary, isLoading: academicLoading } = useQuery(
    'academicSummary',
    studentsAPI.getAcademicSummary
  );

  const { data: notifications, isLoading: notificationsLoading } = useQuery(
    'notifications',
    () => notificationsAPI.getAll({ limit: 5 })
  );

  const { data: upcomingAssignments, isLoading: assignmentsLoading } = useQuery(
    'upcomingAssignments',
    assignmentsAPI.getUpcoming
  );

  const { data: overdueAssignments, isLoading: overdueLoading } = useQuery(
    'overdueAssignments',
    assignmentsAPI.getOverdue
  );

  if (academicLoading || notificationsLoading || assignmentsLoading || overdueLoading) {
    return <LoadingSpinner className="h-64" />;
  }

  const stats = [
    {
      name: 'GPA',
      value: academicSummary?.academicSummary?.gpa || 'N/A',
      icon: AcademicCapIcon,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      name: 'Total Credits',
      value: academicSummary?.academicSummary?.totalCredits || 0,
      icon: BookOpenIcon,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
    },
    {
      name: 'Academic Standing',
      value: academicSummary?.academicSummary?.academicStanding || 'N/A',
      icon: CheckCircleIcon,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      name: 'Unread Notifications',
      value: notifications?.data?.notifications?.filter(n => !n.isRead).length || 0,
      icon: ExclamationTriangleIcon,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100',
    },
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'grade',
      message: 'Grade posted for Computer Science 101',
      time: '2 hours ago',
      icon: CheckCircleIcon,
      color: 'text-green-600',
    },
    {
      id: 2,
      type: 'assignment',
      message: 'Assignment due tomorrow: Programming Assignment 1',
      time: '4 hours ago',
      icon: ClockIcon,
      color: 'text-yellow-600',
    },
    {
      id: 3,
      type: 'course',
      message: 'Successfully registered for Database Systems',
      time: '1 day ago',
      icon: CheckCircleIcon,
      color: 'text-green-600',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold text-gray-900">
          Welcome back, {academicSummary?.academicSummary?.firstName || 'Student'}!
        </h1>
        <p className="text-gray-600 mt-1">
          Here's what's happening with your academic journey today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} aria-hidden="true" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      {stat.name}
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">
                      {stat.value}
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Recent Activity
            </h3>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <activity.icon className={`h-5 w-5 ${activity.color} mt-0.5`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">
                      {activity.message}
                    </p>
                    <p className="text-sm text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Upcoming Assignments */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Upcoming Assignments
            </h3>
            {upcomingAssignments?.data?.assignments?.length > 0 ? (
              <div className="space-y-4">
                {upcomingAssignments.data.assignments.map((assignment) => (
                  <div key={assignment.id} className="border-l-4 border-yellow-400 pl-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {assignment.title}
                        </p>
                        <p className="text-sm text-gray-500">
                          {assignment.courseCode} - Due in {assignment.daysLeft} days
                        </p>
                      </div>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        {assignment.daysLeft} day{assignment.daysLeft !== 1 ? 's' : ''}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500">No upcoming assignments</p>
            )}
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Recent Notifications
            </h3>
            <a href="/notifications" className="text-sm font-medium text-primary-600 hover:text-primary-500">
              View all
            </a>
          </div>
          {notifications?.data?.notifications?.length > 0 ? (
            <div className="space-y-4">
              {notifications.data.notifications.slice(0, 3).map((notification) => (
                <div key={notification.id} className="flex items-start space-x-3">
                  <div className={`flex-shrink-0 w-2 h-2 rounded-full mt-2 ${
                    notification.priority === 'high' ? 'bg-red-400' : 
                    notification.priority === 'medium' ? 'bg-yellow-400' : 'bg-green-400'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">
                      {notification.title}
                    </p>
                    <p className="text-sm text-gray-500">{notification.message}</p>
                    <p className="text-xs text-gray-400 mt-1">
                      {new Date(notification.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No recent notifications</p>
          )}
        </div>
      </div>

      {/* Overdue Assignments Alert */}
      {overdueAssignments?.data?.assignments?.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex">
            <XCircleIcon className="h-5 w-5 text-red-400" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">
                Overdue Assignments
              </h3>
              <div className="mt-2 text-sm text-red-700">
                <ul className="list-disc pl-5 space-y-1">
                  {overdueAssignments.data.assignments.map((assignment) => (
                    <li key={assignment.id}>
                      {assignment.title} - {assignment.courseCode} 
                      ({assignment.daysOverdue} day{assignment.daysOverdue !== 1 ? 's' : ''} overdue)
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard; 