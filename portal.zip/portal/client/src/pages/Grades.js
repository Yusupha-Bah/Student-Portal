import React, { useState } from 'react';
import { useQuery } from 'react-query';
import { gradesAPI } from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';

const Grades = () => {
  const [selectedSemester, setSelectedSemester] = useState('all');
  const [selectedCourse, setSelectedCourse] = useState('all');

  const { data: grades, isLoading } = useQuery(
    ['grades', selectedSemester, selectedCourse],
    () => gradesAPI.getAll({ 
      semester: selectedSemester !== 'all' ? selectedSemester : undefined,
      courseId: selectedCourse !== 'all' ? selectedCourse : undefined 
    })
  );

  const { data: summary, isLoading: summaryLoading } = useQuery(
    'gradeSummary',
    () => gradesAPI.getSummary()
  );

  const { data: recentGrades, isLoading: recentLoading } = useQuery(
    'recentGrades',
    gradesAPI.getRecent
  );

  if (isLoading || summaryLoading || recentLoading) {
    return <LoadingSpinner className="h-64" />;
  }

  const getGradeColor = (grade) => {
    if (grade.startsWith('A')) return 'text-green-600';
    if (grade.startsWith('B')) return 'text-blue-600';
    if (grade.startsWith('C')) return 'text-yellow-600';
    if (grade.startsWith('D')) return 'text-orange-600';
    if (grade === 'F') return 'text-red-600';
    return 'text-gray-600';
  };

  const getGradeStatus = (grade) => {
    if (grade.startsWith('A')) return 'Excellent';
    if (grade.startsWith('B')) return 'Good';
    if (grade.startsWith('C')) return 'Average';
    if (grade.startsWith('D')) return 'Poor';
    if (grade === 'F') return 'Failing';
    return 'Other';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold text-gray-900">My Grades</h1>
        <p className="text-gray-600 mt-1">
          View your academic performance and track your progress
        </p>
      </div>

      {/* Grade Summary */}
      {summary && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm font-medium text-gray-500">Average Score</div>
            <div className="text-2xl font-bold text-gray-900">
              {summary.data?.summary?.averageScore || 0}%
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm font-medium text-gray-500">Total Assignments</div>
            <div className="text-2xl font-bold text-gray-900">
              {summary.data?.summary?.totalAssignments || 0}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm font-medium text-gray-500">Graded</div>
            <div className="text-2xl font-bold text-gray-900">
              {summary.data?.summary?.gradedAssignments || 0}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm font-medium text-gray-500">Pending</div>
            <div className="text-2xl font-bold text-gray-900">
              {summary.data?.summary?.pendingAssignments || 0}
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Semester
            </label>
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(e.target.value)}
              className="input"
            >
              <option value="all">All Semesters</option>
              <option value="Fall">Fall</option>
              <option value="Spring">Spring</option>
              <option value="Summer">Summer</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Course
            </label>
            <select
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
              className="input"
            >
              <option value="all">All Courses</option>
              <option value="CS101">Computer Science 101</option>
              <option value="MATH201">Mathematics 201</option>
              <option value="PHYS101">Physics 101</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grades Table */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Grade Details
          </h3>
          {grades?.data?.grades?.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="table">
                <thead className="table-header">
                  <tr>
                    <th className="table-header-cell">Course</th>
                    <th className="table-header-cell">Assignment</th>
                    <th className="table-header-cell">Score</th>
                    <th className="table-header-cell">Grade</th>
                    <th className="table-header-cell">Status</th>
                    <th className="table-header-cell">Date</th>
                  </tr>
                </thead>
                <tbody className="table-body">
                  {grades.data.grades.map((grade) => (
                    <tr key={grade.id} className="table-row">
                      <td className="table-cell">
                        <div>
                          <div className="font-medium text-gray-900">
                            {grade.course?.courseCode}
                          </div>
                          <div className="text-sm text-gray-500">
                            {grade.course?.courseTitle}
                          </div>
                        </div>
                      </td>
                      <td className="table-cell">
                        <div>
                          <div className="font-medium text-gray-900">
                            {grade.assignmentName}
                          </div>
                          <div className="text-sm text-gray-500">
                            {grade.assignmentType}
                          </div>
                        </div>
                      </td>
                      <td className="table-cell">
                        <div className="text-sm text-gray-900">
                          {grade.score}/{grade.maxScore} ({grade.percentage}%)
                        </div>
                      </td>
                      <td className="table-cell">
                        <span className={`font-semibold ${getGradeColor(grade.letterGrade)}`}>
                          {grade.letterGrade}
                        </span>
                      </td>
                      <td className="table-cell">
                        <span className={`badge ${
                          grade.status === 'Graded' ? 'badge-success' :
                          grade.status === 'Pending' ? 'badge-warning' :
                          'badge-info'
                        }`}>
                          {grade.status}
                        </span>
                      </td>
                      <td className="table-cell text-sm text-gray-500">
                        {new Date(grade.submittedDate).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-gray-500">No grades found</p>
          )}
        </div>
      </div>

      {/* Recent Grades */}
      {recentGrades?.data?.grades?.length > 0 && (
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Recent Grades
            </h3>
            <div className="space-y-4">
              {recentGrades.data.grades.slice(0, 5).map((grade) => (
                <div key={grade.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className={`w-3 h-3 rounded-full ${
                      getGradeColor(grade.letterGrade).replace('text-', 'bg-')
                    }`} />
                    <div>
                      <div className="font-medium text-gray-900">
                        {grade.course?.courseCode} - {grade.assignmentName}
                      </div>
                      <div className="text-sm text-gray-500">
                        {grade.assignmentType} • {new Date(grade.gradedDate).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${getGradeColor(grade.letterGrade)}`}>
                      {grade.letterGrade}
                    </div>
                    <div className="text-sm text-gray-500">
                      {grade.score}/{grade.maxScore}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Grades; 