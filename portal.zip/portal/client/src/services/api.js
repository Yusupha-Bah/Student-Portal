import axios from 'axios';

// Create axios instance
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (userData) => api.post('/auth/register', userData),
  getCurrentUser: () => api.get('/auth/me').then(res => res.data.data.student),
  updateProfile: (profileData) => api.put('/auth/update-profile', profileData).then(res => res.data.data.student),
  changePassword: (currentPassword, newPassword) => api.put('/auth/change-password', { currentPassword, newPassword }),
  forgotPassword: (email) => api.post('/auth/forgot-password', { email }),
};

// Students API
export const studentsAPI = {
  getProfile: () => api.get('/students/profile'),
  getAcademicSummary: () => api.get('/students/academic-summary'),
  getSchedule: () => api.get('/students/schedule'),
  getNotifications: (params) => api.get('/students/notifications', { params }),
  markNotificationRead: (id) => api.put(`/students/notifications/${id}/read`),
  getFinancial: () => api.get('/students/financial'),
};

// Courses API
export const coursesAPI = {
  getAll: (params) => api.get('/courses', { params }),
  getById: (id) => api.get(`/courses/${id}`),
  getByCode: (code) => api.get(`/courses/code/${code}`),
  getByDepartment: (department) => api.get(`/courses/department/${department}`),
  getByLevel: (level) => api.get(`/courses/level/${level}`),
  getSchedule: (semester, academicYear) => api.get(`/courses/schedule/${semester}/${academicYear}`),
  search: (query) => api.get('/courses/search', { params: { q: query } }),
  getStats: () => api.get('/courses/stats'),
};

// Grades API
export const gradesAPI = {
  getAll: (params) => api.get('/grades', { params }),
  getById: (id) => api.get(`/grades/${id}`),
  getByCourse: (courseId) => api.get(`/grades/course/${courseId}`),
  getBySemester: (semester, academicYear) => api.get(`/grades/semester/${semester}/${academicYear}`),
  getSummary: (params) => api.get('/grades/summary', { params }),
  getRecent: () => api.get('/grades/recent'),
  getByType: (type) => api.get(`/grades/type/${type}`),
};

// Registrations API
export const registrationsAPI = {
  getAll: (params) => api.get('/registrations', { params }),
  register: (courseId) => api.post('/registrations', { courseId }),
  drop: (id) => api.delete(`/registrations/${id}`),
  getSummary: () => api.get('/registrations/summary'),
};

// Assignments API
export const assignmentsAPI = {
  getAll: (params) => api.get('/assignments', { params }),
  getById: (id) => api.get(`/assignments/${id}`),
  submit: (id, submissionData) => api.post(`/assignments/${id}/submit`, submissionData),
  getUpcoming: () => api.get('/assignments/upcoming'),
  getOverdue: () => api.get('/assignments/overdue'),
};

// Notifications API
export const notificationsAPI = {
  getAll: (params) => api.get('/notifications', { params }),
  markAsRead: (id) => api.put(`/notifications/${id}/read`),
  markAllAsRead: () => api.put('/notifications/read-all'),
  delete: (id) => api.delete(`/notifications/${id}`),
  getStats: () => api.get('/notifications/stats'),
  getByType: (type) => api.get(`/notifications/type/${type}`),
};

// Financial API
export const financialAPI = {
  getInfo: () => api.get('/financial'),
  getPayments: () => api.get('/financial/payments'),
  getTuitionBreakdown: () => api.get('/financial/tuition-breakdown'),
  getPaymentMethods: () => api.get('/financial/payment-methods'),
  processPayment: (paymentData) => api.post('/financial/pay', paymentData),
  getFinancialAid: () => api.get('/financial/aid'),
  getStatements: () => api.get('/financial/statements'),
};

export default api; 