const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
  courseCode: {
    type: String,
    required: [true, 'Course code is required'],
    unique: true,
    trim: true,
    uppercase: true
  },
  courseTitle: {
    type: String,
    required: [true, 'Course title is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Course description is required']
  },
  credits: {
    type: Number,
    required: [true, 'Credit hours are required'],
    min: [1, 'Credits must be at least 1'],
    max: [6, 'Credits cannot exceed 6']
  },
  department: {
    type: String,
    required: [true, 'Department is required']
  },
  level: {
    type: String,
    required: [true, 'Level is required'],
    enum: ['100', '200', '300', '400', 'Graduate']
  },
  semester: {
    type: String,
    required: [true, 'Semester is required'],
    enum: ['Fall', 'Spring', 'Summer']
  },
  academicYear: {
    type: String,
    required: [true, 'Academic year is required']
  },
  instructor: {
    name: {
      type: String,
      required: [true, 'Instructor name is required']
    },
    email: {
      type: String,
      required: [true, 'Instructor email is required']
    },
    phone: String,
    office: String
  },
  schedule: {
    days: {
      type: [String],
      required: [true, 'Class days are required'],
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    },
    startTime: {
      type: String,
      required: [true, 'Start time is required']
    },
    endTime: {
      type: String,
      required: [true, 'End time is required']
    },
    room: {
      type: String,
      required: [true, 'Room number is required']
    },
    building: String
  },
  capacity: {
    type: Number,
    required: [true, 'Class capacity is required'],
    min: [1, 'Capacity must be at least 1']
  },
  enrolled: {
    type: Number,
    default: 0,
    min: [0, 'Enrolled cannot be negative']
  },
  prerequisites: [{
    type: String,
    ref: 'Course'
  }],
  coRequisites: [{
    type: String,
    ref: 'Course'
  }],
  syllabus: {
    type: String,
    default: ''
  },
  objectives: [{
    type: String
  }],
  learningOutcomes: [{
    type: String
  }],
  textbooks: [{
    title: String,
    author: String,
    isbn: String,
    required: Boolean
  }],
  gradingPolicy: {
    assignments: {
      type: Number,
      default: 30
    },
    midterm: {
      type: Number,
      default: 30
    },
    final: {
      type: Number,
      default: 40
    }
  },
  status: {
    type: String,
    enum: ['Active', 'Inactive', 'Full', 'Cancelled'],
    default: 'Active'
  },
  isOnline: {
    type: Boolean,
    default: false
  },
  meetingUrl: String,
  notes: String
}, {
  timestamps: true
});

// Virtual for availability
CourseSchema.virtual('isAvailable').get(function() {
  return this.status === 'Active' && this.enrolled < this.capacity;
});

// Virtual for enrollment percentage
CourseSchema.virtual('enrollmentPercentage').get(function() {
  return Math.round((this.enrolled / this.capacity) * 100);
});

// Index for better query performance
CourseSchema.index({ courseCode: 1, semester: 1, academicYear: 1 });
CourseSchema.index({ department: 1, level: 1 });

module.exports = mongoose.model('Course', CourseSchema); 