const mongoose = require('mongoose');

const GradeSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.ObjectId,
    ref: 'Student',
    required: true
  },
  course: {
    type: mongoose.Schema.ObjectId,
    ref: 'Course',
    required: true
  },
  semester: {
    type: String,
    required: [true, 'Semester is required'],
    enum: ['Fall', 'Spring', 'Summer']
  },
  academicYear: {
    type: String,
    required: [true, 'Academic year is required']
  },
  assignmentType: {
    type: String,
    required: [true, 'Assignment type is required'],
    enum: ['Assignment', 'Quiz', 'Midterm', 'Final', 'Project', 'Lab', 'Participation', 'Other']
  },
  assignmentName: {
    type: String,
    required: [true, 'Assignment name is required']
  },
  score: {
    type: Number,
    required: [true, 'Score is required'],
    min: [0, 'Score cannot be negative'],
    max: [100, 'Score cannot exceed 100']
  },
  maxScore: {
    type: Number,
    required: [true, 'Maximum score is required'],
    min: [1, 'Maximum score must be at least 1']
  },
  percentage: {
    type: Number,
    min: [0, 'Percentage cannot be negative'],
    max: [100, 'Percentage cannot exceed 100']
  },
  letterGrade: {
    type: String,
    enum: ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'F', 'I', 'W', 'P', 'NP'],
    required: [true, 'Letter grade is required']
  },
  gradePoints: {
    type: Number,
    required: [true, 'Grade points are required'],
    min: [0, 'Grade points cannot be negative'],
    max: [4.0, 'Grade points cannot exceed 4.0']
  },
  weight: {
    type: Number,
    default: 1,
    min: [0, 'Weight cannot be negative']
  },
  dueDate: {
    type: Date,
    required: [true, 'Due date is required']
  },
  submittedDate: {
    type: Date,
    default: Date.now
  },
  gradedDate: {
    type: Date
  },
  gradedBy: {
    type: mongoose.Schema.ObjectId,
    ref: 'Instructor'
  },
  comments: {
    type: String,
    maxlength: [500, 'Comments cannot exceed 500 characters']
  },
  isLate: {
    type: Boolean,
    default: false
  },
  isExcused: {
    type: Boolean,
    default: false
  },
  isDropped: {
    type: Boolean,
    default: false
  },
  status: {
    type: String,
    enum: ['Pending', 'Graded', 'Disputed', 'Updated'],
    default: 'Pending'
  }
}, {
  timestamps: true
});

// Calculate percentage before saving
GradeSchema.pre('save', function(next) {
  if (this.score && this.maxScore) {
    this.percentage = Math.round((this.score / this.maxScore) * 100);
  }
  next();
});

// Virtual for grade status
GradeSchema.virtual('gradeStatus').get(function() {
  if (this.letterGrade === 'A' || this.letterGrade === 'A+') return 'Excellent';
  if (this.letterGrade === 'A-') return 'Very Good';
  if (this.letterGrade === 'B+' || this.letterGrade === 'B') return 'Good';
  if (this.letterGrade === 'B-') return 'Above Average';
  if (this.letterGrade === 'C+' || this.letterGrade === 'C') return 'Average';
  if (this.letterGrade === 'C-') return 'Below Average';
  if (this.letterGrade === 'D+' || this.letterGrade === 'D') return 'Poor';
  if (this.letterGrade === 'F') return 'Failing';
  return 'Other';
});

// Index for better query performance
GradeSchema.index({ student: 1, course: 1, semester: 1, academicYear: 1 });
GradeSchema.index({ student: 1, assignmentType: 1 });

module.exports = mongoose.model('Grade', GradeSchema); 