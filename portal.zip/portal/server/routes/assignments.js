const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @desc    Get student assignments
// @route   GET /api/assignments
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { courseId, status, type } = req.query;

    // Mock assignments - in real app, this would come from an assignments collection
    const assignments = [
      {
        id: 1,
        courseCode: 'CS101',
        courseTitle: 'Introduction to Computer Science',
        title: 'Programming Assignment 1',
        description: 'Create a simple calculator program in Python',
        type: 'Assignment',
        dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
        maxScore: 100,
        weight: 15,
        status: 'Pending',
        submitted: false,
        submittedDate: null,
        score: null,
        grade: null,
        feedback: null
      },
      {
        id: 2,
        courseCode: 'MATH201',
        courseTitle: 'Calculus I',
        title: 'Quiz 3 - Derivatives',
        description: 'Quiz covering derivative rules and applications',
        type: 'Quiz',
        dueDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        maxScore: 50,
        weight: 10,
        status: 'Graded',
        submitted: true,
        submittedDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        score: 42,
        grade: 'B+',
        feedback: 'Good work on most problems. Review chain rule for future assignments.'
      },
      {
        id: 3,
        courseCode: 'CS101',
        courseTitle: 'Introduction to Computer Science',
        title: 'Midterm Exam',
        description: 'Comprehensive exam covering first half of course material',
        type: 'Exam',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        maxScore: 200,
        weight: 30,
        status: 'Pending',
        submitted: false,
        submittedDate: null,
        score: null,
        grade: null,
        feedback: null
      }
    ];

    let filteredAssignments = assignments;

    if (courseId) {
      filteredAssignments = assignments.filter(a => a.courseCode === courseId);
    }

    if (status) {
      filteredAssignments = filteredAssignments.filter(a => a.status === status);
    }

    if (type) {
      filteredAssignments = filteredAssignments.filter(a => a.type === type);
    }

    res.status(200).json({
      status: 'success',
      count: filteredAssignments.length,
      data: {
        assignments: filteredAssignments
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get assignment by ID
// @route   GET /api/assignments/:id
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const { id } = req.params;

    // Mock assignment details
    const assignment = {
      id: parseInt(id),
      courseCode: 'CS101',
      courseTitle: 'Introduction to Computer Science',
      title: 'Programming Assignment 1',
      description: 'Create a simple calculator program in Python that can perform basic arithmetic operations (addition, subtraction, multiplication, division). The program should handle user input and display results appropriately.',
      type: 'Assignment',
      dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
      maxScore: 100,
        weight: 15,
        status: 'Pending',
        submitted: false,
        submittedDate: null,
        score: null,
        grade: null,
        feedback: null,
        requirements: [
          'Program must compile and run without errors',
          'Must handle all four basic arithmetic operations',
          'Include proper input validation',
          'Add comments to explain code logic',
          'Submit source code file (.py)'
        ],
        rubric: {
          'Functionality': 40,
          'Code Quality': 25,
          'Documentation': 20,
          'Testing': 15
        }
    };

    res.status(200).json({
      status: 'success',
      data: {
        assignment
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Submit assignment
// @route   POST /api/assignments/:id/submit
// @access  Private
router.post('/:id/submit', protect, async (req, res) => {
  try {
    const { id } = req.params;
    const { submissionText, attachments } = req.body;

    // In real app, save submission to database
    const submission = {
      id: Date.now(),
      assignmentId: id,
      studentId: req.student.id,
      submissionText,
      attachments,
      submittedDate: new Date(),
      status: 'Submitted'
    };

    res.status(201).json({
      status: 'success',
      message: 'Assignment submitted successfully',
      data: {
        submission
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get upcoming assignments
// @route   GET /api/assignments/upcoming
// @access  Private
router.get('/upcoming', protect, async (req, res) => {
  try {
    const upcomingAssignments = [
      {
        id: 1,
        courseCode: 'CS101',
        title: 'Programming Assignment 1',
        dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
        daysLeft: 1
      },
      {
        id: 3,
        courseCode: 'CS101',
        title: 'Midterm Exam',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        daysLeft: 7
      }
    ];

    res.status(200).json({
      status: 'success',
      count: upcomingAssignments.length,
      data: {
        assignments: upcomingAssignments
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get overdue assignments
// @route   GET /api/assignments/overdue
// @access  Private
router.get('/overdue', protect, async (req, res) => {
  try {
    const overdueAssignments = [
      {
        id: 4,
        courseCode: 'PHYS101',
        title: 'Lab Report 2',
        dueDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        daysOverdue: 2
      }
    ];

    res.status(200).json({
      status: 'success',
      count: overdueAssignments.length,
      data: {
        assignments: overdueAssignments
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 