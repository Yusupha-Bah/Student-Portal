const express = require('express');
const { body, validationResult } = require('express-validator');
const { protect } = require('../middleware/auth');
const Student = require('../models/Student');

const router = express.Router();

// @desc    Register student
// @route   POST /api/auth/register
// @access  Public
router.post('/register', [
  body('studentId', 'Student ID is required').not().isEmpty(),
  body('firstName', 'First name is required').not().isEmpty(),
  body('lastName', 'Last name is required').not().isEmpty(),
  body('email', 'Please include a valid email').isEmail(),
  body('password', 'Please enter a password with 6 or more characters').isLength({ min: 6 }),
  body('dateOfBirth', 'Date of birth is required').not().isEmpty(),
  body('gender', 'Gender is required').isIn(['Male', 'Female', 'Other']),
  body('phone', 'Phone number is required').not().isEmpty(),
  body('program', 'Program is required').not().isEmpty(),
  body('level', 'Level is required').isIn(['100', '200', '300', '400', 'Graduate']),
  body('department', 'Department is required').not().isEmpty()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      status: 'error',
      errors: errors.array()
    });
  }

  try {
    const {
      studentId,
      firstName,
      lastName,
      email,
      password,
      dateOfBirth,
      gender,
      phone,
      program,
      level,
      department,
      address
    } = req.body;

    // Check if student already exists
    const existingStudent = await Student.findOne({
      $or: [{ email }, { studentId }]
    });

    if (existingStudent) {
      return res.status(400).json({
        status: 'error',
        message: 'Student with this email or student ID already exists'
      });
    }

    // Create student
    const student = await Student.create({
      studentId,
      firstName,
      lastName,
      email,
      password,
      dateOfBirth,
      gender,
      phone,
      program,
      level,
      department,
      address
    });

    // Create token
    const token = student.getSignedJwtToken();

    res.status(201).json({
      status: 'success',
      message: 'Student registered successfully',
      token,
      data: {
        student: {
          id: student._id,
          studentId: student.studentId,
          firstName: student.firstName,
          lastName: student.lastName,
          email: student.email,
          program: student.program,
          level: student.level,
          department: student.department,
          gpa: student.gpa,
          status: student.status
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Login student
// @route   POST /api/auth/login
// @access  Public
router.post('/login', [
  body('email', 'Please include a valid email').isEmail(),
  body('password', 'Password is required').exists()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      status: 'error',
      errors: errors.array()
    });
  }

  try {
    const { email, password } = req.body;

    // Check for student
    const student = await Student.findOne({ email }).select('+password');

    if (!student) {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid credentials'
      });
    }

    // Check if password matches
    const isMatch = await student.matchPassword(password);

    if (!isMatch) {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid credentials'
      });
    }

    // Check if student is active
    if (student.status !== 'Active') {
      return res.status(401).json({
        status: 'error',
        message: 'Account is not active. Please contact administration.'
      });
    }

    // Update last login
    student.lastLogin = new Date();
    await student.save();

    // Create token
    const token = student.getSignedJwtToken();

    res.status(200).json({
      status: 'success',
      message: 'Login successful',
      token,
      data: {
        student: {
          id: student._id,
          studentId: student.studentId,
          firstName: student.firstName,
          lastName: student.lastName,
          email: student.email,
          program: student.program,
          level: student.level,
          department: student.department,
          gpa: student.gpa,
          status: student.status,
          profilePicture: student.profilePicture,
          lastLogin: student.lastLogin
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get current logged in student
// @route   GET /api/auth/me
// @access  Private
router.get('/me', protect, async (req, res) => {
  try {
    const student = await Student.findById(req.student.id);

    res.status(200).json({
      status: 'success',
      data: {
        student: {
          id: student._id,
          studentId: student.studentId,
          firstName: student.firstName,
          lastName: student.lastName,
          email: student.email,
          program: student.program,
          level: student.level,
          department: student.department,
          gpa: student.gpa,
          status: student.status,
          profilePicture: student.profilePicture,
          lastLogin: student.lastLogin,
          totalCredits: student.totalCredits,
          advisor: student.advisor,
          emergencyContact: student.emergencyContact
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Update student profile
// @route   PUT /api/auth/update-profile
// @access  Private
router.put('/update-profile', protect, [
  body('firstName', 'First name is required').not().isEmpty(),
  body('lastName', 'Last name is required').not().isEmpty(),
  body('phone', 'Phone number is required').not().isEmpty()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      status: 'error',
      errors: errors.array()
    });
  }

  try {
    const { firstName, lastName, phone, address, emergencyContact } = req.body;

    const student = await Student.findByIdAndUpdate(
      req.student.id,
      {
        firstName,
        lastName,
        phone,
        address,
        emergencyContact
      },
      {
        new: true,
        runValidators: true
      }
    );

    res.status(200).json({
      status: 'success',
      message: 'Profile updated successfully',
      data: {
        student: {
          id: student._id,
          studentId: student.studentId,
          firstName: student.firstName,
          lastName: student.lastName,
          email: student.email,
          phone: student.phone,
          address: student.address,
          emergencyContact: student.emergencyContact
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Change password
// @route   PUT /api/auth/change-password
// @access  Private
router.put('/change-password', protect, [
  body('currentPassword', 'Current password is required').exists(),
  body('newPassword', 'New password must be at least 6 characters').isLength({ min: 6 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      status: 'error',
      errors: errors.array()
    });
  }

  try {
    const { currentPassword, newPassword } = req.body;

    const student = await Student.findById(req.student.id).select('+password');

    // Check current password
    const isMatch = await student.matchPassword(currentPassword);

    if (!isMatch) {
      return res.status(400).json({
        status: 'error',
        message: 'Current password is incorrect'
      });
    }

    // Update password
    student.password = newPassword;
    await student.save();

    res.status(200).json({
      status: 'success',
      message: 'Password changed successfully'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Forgot password
// @route   POST /api/auth/forgot-password
// @access  Public
router.post('/forgot-password', [
  body('email', 'Please include a valid email').isEmail()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      status: 'error',
      errors: errors.array()
    });
  }

  try {
    const { email } = req.body;

    const student = await Student.findOne({ email });

    if (!student) {
      return res.status(404).json({
        status: 'error',
        message: 'No student found with this email'
      });
    }

    // Generate reset token
    const resetToken = student.getResetPasswordToken();
    await student.save({ validateBeforeSave: false });

    // TODO: Send email with reset token
    // For now, just return success message
    res.status(200).json({
      status: 'success',
      message: 'Password reset email sent'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 