const express = require('express');
const { protect } = require('../middleware/auth');
const Course = require('../models/Course');

const router = express.Router();

// @desc    Get all available courses
// @route   GET /api/courses
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { semester, academicYear, department, level, search = '' } = req.query;

    const query = { status: 'Active' };

    if (semester) query.semester = semester;
    if (academicYear) query.academicYear = academicYear;
    if (department) query.department = department;
    if (level) query.level = level;
    if (search) {
      query.$or = [
        { courseCode: { $regex: search, $options: 'i' } },
        { courseTitle: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    const courses = await Course.find(query)
      .sort({ courseCode: 1 });

    res.status(200).json({
      status: 'success',
      count: courses.length,
      data: {
        courses
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get single course
// @route   GET /api/courses/:id
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);

    if (!course) {
      return res.status(404).json({
        status: 'error',
        message: 'Course not found'
      });
    }

    res.status(200).json({
      status: 'success',
      data: {
        course
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get course by code
// @route   GET /api/courses/code/:code
// @access  Private
router.get('/code/:code', protect, async (req, res) => {
  try {
    const course = await Course.findOne({ courseCode: req.params.code.toUpperCase() });

    if (!course) {
      return res.status(404).json({
        status: 'error',
        message: 'Course not found'
      });
    }

    res.status(200).json({
      status: 'success',
      data: {
        course
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get courses by department
// @route   GET /api/courses/department/:department
// @access  Private
router.get('/department/:department', protect, async (req, res) => {
  try {
    const courses = await Course.find({
      department: req.params.department,
      status: 'Active'
    }).sort({ courseCode: 1 });

    res.status(200).json({
      status: 'success',
      count: courses.length,
      data: {
        courses
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get courses by level
// @route   GET /api/courses/level/:level
// @access  Private
router.get('/level/:level', protect, async (req, res) => {
  try {
    const courses = await Course.find({
      level: req.params.level,
      status: 'Active'
    }).sort({ courseCode: 1 });

    res.status(200).json({
      status: 'success',
      count: courses.length,
      data: {
        courses
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get course schedule
// @route   GET /api/courses/schedule/:semester/:academicYear
// @access  Private
router.get('/schedule/:semester/:academicYear', protect, async (req, res) => {
  try {
    const { semester, academicYear } = req.params;

    const courses = await Course.find({
      semester,
      academicYear,
      status: 'Active'
    }).sort({ 'schedule.days': 1, 'schedule.startTime': 1 });

    res.status(200).json({
      status: 'success',
      count: courses.length,
      data: {
        courses
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Search courses
// @route   GET /api/courses/search
// @access  Private
router.get('/search', protect, async (req, res) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({
        status: 'error',
        message: 'Search query is required'
      });
    }

    const courses = await Course.find({
      $or: [
        { courseCode: { $regex: q, $options: 'i' } },
        { courseTitle: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } },
        { 'instructor.name': { $regex: q, $options: 'i' } }
      ],
      status: 'Active'
    }).sort({ courseCode: 1 });

    res.status(200).json({
      status: 'success',
      count: courses.length,
      data: {
        courses
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get course statistics
// @route   GET /api/courses/stats
// @access  Private
router.get('/stats', protect, async (req, res) => {
  try {
    const totalCourses = await Course.countDocuments({ status: 'Active' });
    const coursesByDepartment = await Course.aggregate([
      { $match: { status: 'Active' } },
      { $group: { _id: '$department', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    const coursesByLevel = await Course.aggregate([
      { $match: { status: 'Active' } },
      { $group: { _id: '$level', count: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]);

    res.status(200).json({
      status: 'success',
      data: {
        totalCourses,
        coursesByDepartment,
        coursesByLevel
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 