const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @desc    Get student financial information
// @route   GET /api/financial
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const financialInfo = {
      balance: 2500.00,
      tuition: 5000.00,
      paid: 2500.00,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      paymentPlan: 'Monthly',
      lateFees: 0.00,
      scholarships: 1000.00,
      loans: 0.00,
      status: 'Partial Payment'
    };

    res.status(200).json({
      status: 'success',
      data: {
        financialInfo
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get payment history
// @route   GET /api/financial/payments
// @access  Private
router.get('/payments', protect, async (req, res) => {
  try {
    const payments = [
      {
        id: 1,
        date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        amount: 2500.00,
        method: 'Credit Card',
        status: 'Completed',
        reference: 'PAY-2024-001',
        description: 'Fall 2024 Tuition Payment'
      },
      {
        id: 2,
        date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
        amount: 2500.00,
        method: 'Bank Transfer',
        status: 'Completed',
        reference: 'PAY-2024-002',
        description: 'Fall 2024 Tuition Payment'
      }
    ];

    res.status(200).json({
      status: 'success',
      count: payments.length,
      data: {
        payments
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get tuition breakdown
// @route   GET /api/financial/tuition-breakdown
// @access  Private
router.get('/tuition-breakdown', protect, async (req, res) => {
  try {
    const breakdown = {
      tuition: 4000.00,
      fees: 500.00,
      books: 300.00,
      housing: 200.00,
      total: 5000.00,
      scholarships: -1000.00,
      netAmount: 4000.00
    };

    res.status(200).json({
      status: 'success',
      data: {
        breakdown
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get payment methods
// @route   GET /api/financial/payment-methods
// @access  Private
router.get('/payment-methods', protect, async (req, res) => {
  try {
    const paymentMethods = [
      {
        id: 1,
        type: 'Credit Card',
        last4: '1234',
        brand: 'Visa',
        isDefault: true
      },
      {
        id: 2,
        type: 'Bank Account',
        last4: '5678',
        bank: 'Chase Bank',
        isDefault: false
      }
    ];

    res.status(200).json({
      status: 'success',
      data: {
        paymentMethods
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Process payment
// @route   POST /api/financial/pay
// @access  Private
router.post('/pay', protect, async (req, res) => {
  try {
    const { amount, paymentMethodId, description } = req.body;

    // In real app, process payment through payment gateway
    const payment = {
      id: Date.now(),
      amount: parseFloat(amount),
      method: 'Credit Card',
      status: 'Processing',
      reference: `PAY-${Date.now()}`,
      description: description || 'Tuition Payment',
      date: new Date()
    };

    res.status(201).json({
      status: 'success',
      message: 'Payment processed successfully',
      data: {
        payment
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get financial aid information
// @route   GET /api/financial/aid
// @access  Private
router.get('/aid', protect, async (req, res) => {
  try {
    const financialAid = {
      scholarships: [
        {
          name: 'Academic Excellence Scholarship',
          amount: 1000.00,
          status: 'Awarded',
          semester: 'Fall 2024'
        }
      ],
      grants: [],
      loans: [],
      totalAid: 1000.00
    };

    res.status(200).json({
      status: 'success',
      data: {
        financialAid
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get billing statements
// @route   GET /api/financial/statements
// @access  Private
router.get('/statements', protect, async (req, res) => {
  try {
    const statements = [
      {
        id: 1,
        period: 'Fall 2024',
        date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        amount: 5000.00,
        status: 'Partial Payment',
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      },
      {
        id: 2,
        period: 'Spring 2024',
        date: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000),
        amount: 5000.00,
        status: 'Paid',
        dueDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
      }
    ];

    res.status(200).json({
      status: 'success',
      count: statements.length,
      data: {
        statements
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 