const express = require('express');
const { protect } = require('../middleware/auth');
const Grade = require('../models/Grade');
const Course = require('../models/Course');

const router = express.Router();

// @desc    Get student grades
// @route   GET /api/grades
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { semester, academicYear, courseId } = req.query;

    const query = { student: req.student.id };

    if (semester) query.semester = semester;
    if (academicYear) query.academicYear = academicYear;
    if (courseId) query.course = courseId;

    const grades = await Grade.find(query)
      .populate('course', 'courseCode courseTitle credits')
      .sort({ dueDate: -1 });

    res.status(200).json({
      status: 'success',
      count: grades.length,
      data: {
        grades
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get grade by ID
// @route   GET /api/grades/:id
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const grade = await Grade.findById(req.params.id)
      .populate('course', 'courseCode courseTitle credits')
      .populate('gradedBy', 'firstName lastName');

    if (!grade) {
      return res.status(404).json({
        status: 'error',
        message: 'Grade not found'
      });
    }

    // Check if the grade belongs to the student
    if (grade.student.toString() !== req.student.id) {
      return res.status(403).json({
        status: 'error',
        message: 'Not authorized to access this grade'
      });
    }

    res.status(200).json({
      status: 'success',
      data: {
        grade
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get grades by course
// @route   GET /api/grades/course/:courseId
// @access  Private
router.get('/course/:courseId', protect, async (req, res) => {
  try {
    const grades = await Grade.find({
      student: req.student.id,
      course: req.params.courseId
    })
      .populate('course', 'courseCode courseTitle credits')
      .sort({ dueDate: -1 });

    res.status(200).json({
      status: 'success',
      count: grades.length,
      data: {
        grades
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get grades by semester
// @route   GET /api/grades/semester/:semester/:academicYear
// @access  Private
router.get('/semester/:semester/:academicYear', protect, async (req, res) => {
  try {
    const { semester, academicYear } = req.params;

    const grades = await Grade.find({
      student: req.student.id,
      semester,
      academicYear
    })
      .populate('course', 'courseCode courseTitle credits')
      .sort({ dueDate: -1 });

    res.status(200).json({
      status: 'success',
      count: grades.length,
      data: {
        grades
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get grade summary
// @route   GET /api/grades/summary
// @access  Private
router.get('/summary', protect, async (req, res) => {
  try {
    const { semester, academicYear } = req.query;

    const query = { student: req.student.id };
    if (semester) query.semester = semester;
    if (academicYear) query.academicYear = academicYear;

    const grades = await Grade.find(query)
      .populate('course', 'courseCode courseTitle credits');

    // Calculate summary statistics
    const totalAssignments = grades.length;
    const gradedAssignments = grades.filter(grade => grade.status === 'Graded').length;
    const pendingAssignments = grades.filter(grade => grade.status === 'Pending').length;

    const averageScore = grades.length > 0 
      ? grades.reduce((sum, grade) => sum + grade.percentage, 0) / grades.length 
      : 0;

    const gradeDistribution = {
      'A+': grades.filter(g => g.letterGrade === 'A+').length,
      'A': grades.filter(g => g.letterGrade === 'A').length,
      'A-': grades.filter(g => g.letterGrade === 'A-').length,
      'B+': grades.filter(g => g.letterGrade === 'B+').length,
      'B': grades.filter(g => g.letterGrade === 'B').length,
      'B-': grades.filter(g => g.letterGrade === 'B-').length,
      'C+': grades.filter(g => g.letterGrade === 'C+').length,
      'C': grades.filter(g => g.letterGrade === 'C').length,
      'C-': grades.filter(g => g.letterGrade === 'C-').length,
      'D+': grades.filter(g => g.letterGrade === 'D+').length,
      'D': grades.filter(g => g.letterGrade === 'D').length,
      'F': grades.filter(g => g.letterGrade === 'F').length
    };

    res.status(200).json({
      status: 'success',
      data: {
        summary: {
          totalAssignments,
          gradedAssignments,
          pendingAssignments,
          averageScore: Math.round(averageScore * 100) / 100,
          gradeDistribution
        },
        grades
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get recent grades
// @route   GET /api/grades/recent
// @access  Private
router.get('/recent', protect, async (req, res) => {
  try {
    const recentGrades = await Grade.find({ student: req.student.id })
      .populate('course', 'courseCode courseTitle')
      .sort({ gradedDate: -1 })
      .limit(10);

    res.status(200).json({
      status: 'success',
      count: recentGrades.length,
      data: {
        grades: recentGrades
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get grades by assignment type
// @route   GET /api/grades/type/:type
// @access  Private
router.get('/type/:type', protect, async (req, res) => {
  try {
    const grades = await Grade.find({
      student: req.student.id,
      assignmentType: req.params.type
    })
      .populate('course', 'courseCode courseTitle')
      .sort({ dueDate: -1 });

    res.status(200).json({
      status: 'success',
      count: grades.length,
      data: {
        grades
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 