const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

// @desc    Get all notifications
// @route   GET /api/notifications
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { page = 1, limit = 20, unreadOnly = false } = req.query;

    // Mock notifications - in real app, this would come from a notifications collection
    const notifications = [
      {
        id: 1,
        title: 'Assignment Due',
        message: 'Your Computer Science assignment is due tomorrow at 11:59 PM',
        type: 'assignment',
        priority: 'high',
        isRead: false,
        createdAt: new Date(),
        courseCode: 'CS101',
        dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000)
      },
      {
        id: 2,
        title: 'Grade Posted',
        message: 'Your Mathematics quiz grade has been posted. Check your grades section.',
        type: 'grade',
        priority: 'medium',
        isRead: true,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
        courseCode: 'MATH201'
      },
      {
        id: 3,
        title: 'Course Registration Open',
        message: 'Course registration for Spring 2024 is now open. Register early to secure your preferred courses.',
        type: 'registration',
        priority: 'high',
        isRead: false,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000)
      },
      {
        id: 4,
        title: 'Payment Due',
        message: 'Your tuition payment is due in 7 days. Please make payment to avoid late fees.',
        type: 'financial',
        priority: 'high',
        isRead: false,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      },
      {
        id: 5,
        title: 'Academic Advising',
        message: 'Schedule your academic advising appointment for next semester course planning.',
        type: 'academic',
        priority: 'medium',
        isRead: true,
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
      }
    ];

    let filteredNotifications = notifications;

    if (unreadOnly === 'true') {
      filteredNotifications = notifications.filter(n => !n.isRead);
    }

    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const paginatedNotifications = filteredNotifications.slice(startIndex, endIndex);

    res.status(200).json({
      status: 'success',
      data: {
        notifications: paginatedNotifications,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(filteredNotifications.length / limit),
          totalNotifications: filteredNotifications.length,
          unreadCount: notifications.filter(n => !n.isRead).length
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Mark notification as read
// @route   PUT /api/notifications/:id/read
// @access  Private
router.put('/:id/read', protect, async (req, res) => {
  try {
    const { id } = req.params;

    // In real app, update notification in database
    // await Notification.findByIdAndUpdate(id, { isRead: true });

    res.status(200).json({
      status: 'success',
      message: 'Notification marked as read'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Mark all notifications as read
// @route   PUT /api/notifications/read-all
// @access  Private
router.put('/read-all', protect, async (req, res) => {
  try {
    // In real app, update all notifications for the student
    // await Notification.updateMany(
    //   { student: req.student.id, isRead: false },
    //   { isRead: true }
    // );

    res.status(200).json({
      status: 'success',
      message: 'All notifications marked as read'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Delete notification
// @route   DELETE /api/notifications/:id
// @access  Private
router.delete('/:id', protect, async (req, res) => {
  try {
    const { id } = req.params;

    // In real app, delete notification from database
    // await Notification.findByIdAndDelete(id);

    res.status(200).json({
      status: 'success',
      message: 'Notification deleted'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get notification statistics
// @route   GET /api/notifications/stats
// @access  Private
router.get('/stats', protect, async (req, res) => {
  try {
    // Mock statistics
    const stats = {
      total: 5,
      unread: 3,
      byType: {
        assignment: 1,
        grade: 1,
        registration: 1,
        financial: 1,
        academic: 1
      },
      byPriority: {
        high: 3,
        medium: 2,
        low: 0
      }
    };

    res.status(200).json({
      status: 'success',
      data: {
        stats
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get notifications by type
// @route   GET /api/notifications/type/:type
// @access  Private
router.get('/type/:type', protect, async (req, res) => {
  try {
    const { type } = req.params;

    // Mock filtered notifications
    const notifications = [
      {
        id: 1,
        title: 'Assignment Due',
        message: 'Your Computer Science assignment is due tomorrow',
        type: 'assignment',
        priority: 'high',
        isRead: false,
        createdAt: new Date()
      }
    ].filter(n => n.type === type);

    res.status(200).json({
      status: 'success',
      count: notifications.length,
      data: {
        notifications
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 