const express = require('express');
const { protect } = require('../middleware/auth');
const Course = require('../models/Course');

const router = express.Router();

// @desc    Get student registrations
// @route   GET /api/registrations
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const { semester, academicYear } = req.query;

    // Mock registrations - in real app, this would come from a registrations collection
    const registrations = [
      {
        id: 1,
        courseCode: 'CS101',
        courseTitle: 'Introduction to Computer Science',
        credits: 3,
        instructor: 'Dr. Smith',
        schedule: {
          days: ['Monday', 'Wednesday', 'Friday'],
          time: '9:00 AM - 10:00 AM',
          room: 'Room 101',
          building: 'Science Building'
        },
        status: 'Active',
        registrationDate: new Date('2024-01-15'),
        grade: 'A-'
      },
      {
        id: 2,
        courseCode: 'MATH201',
        courseTitle: 'Calculus I',
        credits: 4,
        instructor: 'Prof. Johnson',
        schedule: {
          days: ['Tuesday', 'Thursday'],
          time: '10:00 AM - 11:30 AM',
          room: 'Room 205',
          building: 'Mathematics Building'
        },
        status: 'Active',
        registrationDate: new Date('2024-01-15'),
        grade: 'B+'
      }
    ];

    res.status(200).json({
      status: 'success',
      count: registrations.length,
      data: {
        registrations
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Register for a course
// @route   POST /api/registrations
// @access  Private
router.post('/', protect, async (req, res) => {
  try {
    const { courseId } = req.body;

    // Check if course exists
    const course = await Course.findById(courseId);

    if (!course) {
      return res.status(404).json({
        status: 'error',
        message: 'Course not found'
      });
    }

    // Check if course is available
    if (!course.isAvailable) {
      return res.status(400).json({
        status: 'error',
        message: 'Course is not available for registration'
      });
    }

    // Check if student is already registered
    // In real app, check registrations collection

    // Mock registration
    const registration = {
      id: Date.now(),
      courseCode: course.courseCode,
      courseTitle: course.courseTitle,
      credits: course.credits,
      instructor: course.instructor.name,
      schedule: course.schedule,
      status: 'Active',
      registrationDate: new Date()
    };

    res.status(201).json({
      status: 'success',
      message: 'Successfully registered for course',
      data: {
        registration
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Drop a course
// @route   DELETE /api/registrations/:id
// @access  Private
router.delete('/:id', protect, async (req, res) => {
  try {
    const { id } = req.params;

    // In real app, update registration status in database

    res.status(200).json({
      status: 'success',
      message: 'Course dropped successfully'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get registration summary
// @route   GET /api/registrations/summary
// @access  Private
router.get('/summary', protect, async (req, res) => {
  try {
    // Mock summary data
    const summary = {
      totalCredits: 7,
      totalCourses: 2,
      activeCourses: 2,
      completedCourses: 0,
      currentGPA: 3.5,
      academicStanding: 'Good Standing'
    };

    res.status(200).json({
      status: 'success',
      data: {
        summary
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 