const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const Student = require('../models/Student');

const router = express.Router();

// @desc    Get student profile
// @route   GET /api/students/profile
// @access  Private
router.get('/profile', protect, async (req, res) => {
  try {
    const student = await Student.findById(req.student.id)
      .select('-password')
      .populate('advisor', 'name email phone');

    res.status(200).json({
      status: 'success',
      data: {
        student
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get student academic summary
// @route   GET /api/students/academic-summary
// @access  Private
router.get('/academic-summary', protect, async (req, res) => {
  try {
    const student = await Student.findById(req.student.id)
      .select('gpa totalCredits program level department status');

    // Calculate academic standing
    let academicStanding = 'Good Standing';
    if (student.gpa < 2.0) {
      academicStanding = 'Academic Probation';
    } else if (student.gpa < 2.5) {
      academicStanding = 'Academic Warning';
    }

    res.status(200).json({
      status: 'success',
      data: {
        academicSummary: {
          gpa: student.gpa,
          totalCredits: student.totalCredits,
          program: student.program,
          level: student.level,
          department: student.department,
          status: student.status,
          academicStanding
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get student schedule
// @route   GET /api/students/schedule
// @access  Private
router.get('/schedule', protect, async (req, res) => {
  try {
    // This would typically fetch from course registrations
    // For now, return mock data
    const schedule = [
      {
        courseCode: 'CS101',
        courseTitle: 'Introduction to Computer Science',
        instructor: 'Dr. Smith',
        days: ['Monday', 'Wednesday', 'Friday'],
        time: '9:00 AM - 10:00 AM',
        room: 'Room 101',
        building: 'Science Building'
      },
      {
        courseCode: 'MATH201',
        courseTitle: 'Calculus I',
        instructor: 'Prof. Johnson',
        days: ['Tuesday', 'Thursday'],
        time: '10:00 AM - 11:30 AM',
        room: 'Room 205',
        building: 'Mathematics Building'
      }
    ];

    res.status(200).json({
      status: 'success',
      data: {
        schedule
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get student notifications
// @route   GET /api/students/notifications
// @access  Private
router.get('/notifications', protect, async (req, res) => {
  try {
    // Mock notifications - in real app, this would come from a notifications collection
    const notifications = [
      {
        id: 1,
        title: 'Assignment Due',
        message: 'Your Computer Science assignment is due tomorrow',
        type: 'assignment',
        isRead: false,
        createdAt: new Date()
      },
      {
        id: 2,
        title: 'Grade Posted',
        message: 'Your Mathematics quiz grade has been posted',
        type: 'grade',
        isRead: true,
        createdAt: new Date(Date.now() - 86400000)
      }
    ];

    res.status(200).json({
      status: 'success',
      data: {
        notifications
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Mark notification as read
// @route   PUT /api/students/notifications/:id/read
// @access  Private
router.put('/notifications/:id/read', protect, async (req, res) => {
  try {
    const { id } = req.params;

    // In real app, update notification in database
    res.status(200).json({
      status: 'success',
      message: 'Notification marked as read'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get student financial information
// @route   GET /api/students/financial
// @access  Private
router.get('/financial', protect, async (req, res) => {
  try {
    // Mock financial data
    const financialInfo = {
      balance: 2500.00,
      tuition: 5000.00,
      paid: 2500.00,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      paymentHistory: [
        {
          date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          amount: 2500.00,
          method: 'Credit Card'
        }
      ]
    };

    res.status(200).json({
      status: 'success',
      data: {
        financialInfo
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

// @desc    Get all students (Admin only)
// @route   GET /api/students
// @access  Private/Admin
router.get('/', protect, authorize('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', department = '', level = '' } = req.query;

    const query = {};

    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { studentId: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    if (department) {
      query.department = department;
    }

    if (level) {
      query.level = level;
    }

    const students = await Student.find(query)
      .select('-password')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });

    const total = await Student.countDocuments(query);

    res.status(200).json({
      status: 'success',
      data: {
        students,
        pagination: {
          currentPage: page,
          totalPages: Math.ceil(total / limit),
          totalStudents: total
        }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'error',
      message: 'Server error'
    });
  }
});

module.exports = router; 