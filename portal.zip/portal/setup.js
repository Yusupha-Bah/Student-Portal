#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 Setting up UTG Student Portal...\n');

// Check if Node.js version is compatible
const nodeVersion = process.version;
const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);

if (majorVersion < 16) {
  console.error('❌ Node.js version 16 or higher is required. Current version:', nodeVersion);
  process.exit(1);
}

console.log('✅ Node.js version check passed');

// Create config.env if it doesn't exist
const configPath = path.join(__dirname, 'config.env');
if (!fs.existsSync(configPath)) {
  const defaultConfig = `NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/utg_student_portal
JWT_SECRET=your_jwt_secret_key_here_change_in_production
JWT_EXPIRE=30d
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_email_password
CLIENT_URL=http://localhost:3000`;

  fs.writeFileSync(configPath, defaultConfig);
  console.log('✅ Created config.env file');
} else {
  console.log('✅ config.env file already exists');
}

// Install backend dependencies
console.log('\n📦 Installing backend dependencies...');
try {
  execSync('npm install', { stdio: 'inherit' });
  console.log('✅ Backend dependencies installed');
} catch (error) {
  console.error('❌ Failed to install backend dependencies:', error.message);
  process.exit(1);
}

// Install frontend dependencies
console.log('\n📦 Installing frontend dependencies...');
try {
  execSync('cd client && npm install', { stdio: 'inherit' });
  console.log('✅ Frontend dependencies installed');
} catch (error) {
  console.error('❌ Failed to install frontend dependencies:', error.message);
  process.exit(1);
}

// Create necessary directories
const dirs = [
  'uploads',
  'uploads/assignments',
  'uploads/profiles',
  'logs'
];

dirs.forEach(dir => {
  const dirPath = path.join(__dirname, dir);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    console.log(`✅ Created directory: ${dir}`);
  }
});

console.log('\n🎉 Setup completed successfully!');
console.log('\n📋 Next steps:');
console.log('1. Configure your MongoDB database');
console.log('2. Update config.env with your settings');
console.log('3. Run "npm run dev" to start the application');
console.log('4. Access the application at http://localhost:3000');
console.log('\n📚 For more information, check the README.md file'); 