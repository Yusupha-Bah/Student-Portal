#!/usr/bin/env node

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

console.log('🚀 Starting UTG Student Portal...\n');

// Check if config.env exists
const configPath = path.join(__dirname, 'config.env');
if (!fs.existsSync(configPath)) {
  console.error('❌ config.env file not found. Please run setup.js first.');
  process.exit(1);
}

// Check if node_modules exists
const backendModules = path.join(__dirname, 'node_modules');
const frontendModules = path.join(__dirname, 'client', 'node_modules');

if (!fs.existsSync(backendModules)) {
  console.error('❌ Backend dependencies not installed. Please run setup.js first.');
  process.exit(1);
}

if (!fs.existsSync(frontendModules)) {
  console.error('❌ Frontend dependencies not installed. Please run setup.js first.');
  process.exit(1);
}

// Start the development server
console.log('📦 Starting development servers...\n');

const backend = spawn('npm', ['run', 'server'], {
  stdio: 'inherit',
  shell: true
});

const frontend = spawn('npm', ['start'], {
  stdio: 'inherit',
  shell: true,
  cwd: path.join(__dirname, 'client')
});

// Handle process termination
const cleanup = () => {
  console.log('\n🛑 Shutting down servers...');
  backend.kill();
  frontend.kill();
  process.exit(0);
};

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

// Handle errors
backend.on('error', (error) => {
  console.error('❌ Backend error:', error.message);
  cleanup();
});

frontend.on('error', (error) => {
  console.error('❌ Frontend error:', error.message);
  cleanup();
});

console.log('✅ Servers started successfully!');
console.log('🌐 Frontend: http://localhost:3000');
console.log('🔧 Backend API: http://localhost:5000/api');
console.log('📊 Health Check: http://localhost:5000/api/health');
console.log('\nPress Ctrl+C to stop the servers'); 